package procesos;
import java.util.*;

public class Lista{
    
Scanner leer=new Scanner(System.in);

Nodo primero;
public Lista(){
primero=null;
}

public void crearlista(){
if(primero==null){
System.out.print("NOMBRE: ");
String lo=leer.next();
primero= new Nodo(lo, primero);}
}

public void recorrerlista(){
Nodo n;
n=primero;
if(n==null){
System.out.println("No tiene nombres");}
else{
while(n!=null){
System.out.println(n.dato);
n=n.referencia;}}
}

public void insertarPrimero(){
Nodo n=primero;
if(n==null){
System.out.println("No tiene nombres");}
else{
System.out.print("Dame el nombre :");
String y=leer.next();
Nodo nuevo=new Nodo(y);
nuevo.referencia=n;
primero=nuevo;}
}

public void insertarUltimo(){
Nodo ultimo=null, n=primero;
if(n==null){
System.out.println("No tiene nombres");}
else{
while(n!=null){
ultimo=n;
n=n.referencia;}
System.out.print("Dame el nuevo nombre :");
String y=leer.next();
ultimo.referencia=new Nodo(y);}
}

public void eliminarElemento(){
Nodo n=primero, anterior=null;
boolean encontrado=false;
if(n==null){
System.out.println("No tiene nombres");}
else{
System.out.print("Eliminar :");
Scanner leer=new Scanner(System.in);
String nnom=leer.next();
while((n!=null)&&(encontrado==false)){
encontrado=(nnom.equals(n.dato));
if(encontrado==false){
anterior=n;
n=n.referencia;}}
if(n!=null){
if(n==primero){
primero=n.referencia;}
else{
anterior.referencia=n.referencia;}}}
}

public void insertarElemento(){
Nodo ref=null, n=primero;
boolean encontrado=false;
Scanner leer=new Scanner(System.in);
if(n==null){
System.out.println("No tiene nombres");}
else{
System.out.print("Insertar un elemento despues del :");
String x=leer.next();
while(n!=null){
if(x.equals(n.dato)){
ref=n;
encontrado=true;}
n=n.referencia;}
if(encontrado==true){
System.out.print("Nuevo nombre :");
String y=leer.next();
Nodo nuevo=new Nodo(y);
nuevo.referencia=ref.referencia;
ref.referencia=nuevo;}
else{
System.out.println("Elemento no Encontrado");}}
}

public void buscarElemento(){
Nodo n=primero;
boolean encontrado=false;
if(n==null){
System.out.println("No tiene nombres");}
else{
System.out.print("Escribe el nombre :");
String tw="";
tw=leer.next();
while(n!=null){
if(tw.equals(n.dato)){
System.out.println("Nombre '"+tw+"' fue encontrado en la posicion :"+n);
encontrado=true;}
n=n.referencia;}
if(encontrado==false){
System.out.println("El nombre :"+tw+" no existe");}}
}
}

