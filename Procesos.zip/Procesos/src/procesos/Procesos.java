package procesos;

import java.util.Scanner;

public class Procesos {

    public static void main(String[] args) {

        Scanner leer=new Scanner(System.in);
Lista Lista= new Lista();
int opcion=0;
while(opcion!=8){
/*System.out.println("1.- Crear una lista enlazada");
System.out.println("2.- Insertar nombres al inicio de la lista enlazada");
System.out.println("3.- Insertar nombres al final de la lista");
System.out.println("4.- Insertar nombres entre nodos de la lista");
System.out.println("5.- Buscar un nombre en la lista");
System.out.println("6.- Eliminar nombres de la lista.");
System.out.println("7.- Recorrer la lista de nombres");
System.out.println("8.- Salir");
System.out.print("Teclea una Opcion :");
opcion=leer.nextInt();*/
        System.out.println("1.- Crear un nuevo hogar");
        System.out.println("2.- Ingresar nueva Mascota");
        System.out.println("3.- Ingresar nueva Mascota en medio");
        System.out.println("4.- Ingresar nueva mascota al final");
        System.out.println("5.- Buscar una Mascota");
        System.out.println("6.- Dar de baja a mascota (de la vida)");
        System.out.println("7.- Recorrer la lista de nombres");
        System.out.println("8.- Salir");
        System.out.print("Teclea una Opcion :");
        opcion=leer.nextInt();
                        switch(opcion){
                        case(1): Lista.crearlista();
                        break;
                        case(2): Lista.insertarPrimero();
                        break;
                        case(3): Lista.insertarUltimo();
                        break;
                        case(4): Lista.insertarElemento();
                        break;
                        case(5): Lista.buscarElemento();
                        break;
                        case(6): Lista.eliminarElemento();
                        break;
                        case(7): Lista.recorrerlista();
                        break;
                }
            }       
         }    
      }
